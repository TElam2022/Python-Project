# main4.py
# Guess the number using a while loop

secret_number = 7
guess = int(input("Guess a number between 1 and 10: "))
attempts = 1

while guess != secret_number:
    print("Sorry, try again! Guess a number between 1 and 10:")
    guess = int(input())
    attempts += 1

print("You guessed right after", attempts, "guess(es). You win!")