# main2.py
# Simple calculator using arithmetic operators

num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))

print("Results:")
print("Sum:", num1 + num2)
print("Difference:", num1 - num2)
print("Product:", num1 * num2)
print("Quotient:", num1 / num2)
print("Remainder:", num1 % num2)