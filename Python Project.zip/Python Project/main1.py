# main1.py
# Ask user for information and convert to proper data types

name = input("Enter your name: ")
age = int(input("Enter your age: "))
weight = float(input("Enter your weight: "))
is_student_input = input("Are you a student? (yes/no): ")

# Convert to boolean
if is_student_input.lower() == "yes":
    is_student = True
else:
    is_student = False

print("--- User Information ---")
print("Name:", name)
print("Age:", age)
print("Weight:", weight)
print("Student:", is_student)