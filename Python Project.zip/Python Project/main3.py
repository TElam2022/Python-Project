# main3.py
# Compare two integers and check for negatives

num1 = int(input("Enter first integer: "))
num2 = int(input("Enter second integer: "))

if num1 > num2:
    print(num1, "is greater than" ,num2)
elif num1 < num2:
    print(num1, "is less than" ,num2)
else:
    print(num1, "is equal to" ,num2)
if num1 < 0 or num2 < 0:
    print("At least one of the numbers is negative.")