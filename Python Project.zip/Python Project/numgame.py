# numgame.py
# Complete number guessing game using functions

import random

def welcome_message():
    print("Welcome to 'Guess the Number' game!")
    print("You have to guess the secret number within a limited number of attempts.")
    print("Let's start!\n")

def get_guess_input():
    while True:
        try:
            guess = int(input("Guess a number between 1 and 10: "))
            if guess < 1 or guess > 10:
                print("Please guess a number between 1 and 10.")
            else:
                return guess
        except ValueError:
            print("Invalid input! Please enter a valid number.")

def check_guess(guess, secret_number, attempts, wrong_guesses):
    if guess > secret_number:
        print("You guessed too high.")
        wrong_guesses.append(guess)
        return attempts - 1
    elif guess < secret_number:
        print("You guessed too low.")
        wrong_guesses.append(guess)
        return attempts - 1
    else:
        print("Congratulations! You guessed the secret number!")
        return attempts

def play_game():
    secret_number = random.randint(1, 10)
    attempts = 5
    wrong_guesses = []
    welcome_message()

    while attempts > 0:
        print("You have" ,attempts, "attempts left:")
        guess = get_guess_input()
        attempts = check_guess(guess, secret_number, attempts, wrong_guesses)
        if guess == secret_number:
            break
        elif attempts == 0:
            print("Game Over! The secret number was", secret_number)
            print("Your wrong guesses were:", wrong_guesses)
            print("Better luck next time!")

# Start the game
play_game()