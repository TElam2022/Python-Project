# main7.py
# Multiply number by 10 with function and exception handling

def multiply10(num):
    return num * 10

while True:
    try:
        number = int(input("Enter a whole number: "))
        answer = multiply10(number)
        print(number, "multiplied by 10 is:" ,answer)
        break
    except ValueError:
        print("Invalid input! Please enter a valid whole number.")