# main6.py
# Ask for favorite colors and store them in a list

colors = []

for i in range(3):
    color = input("Enter favorite color: ")
    colors.append(color)

print("Your favorite colors are:" ,colors)