# main5.py
# Guess the number using a for loop with nested if

secret_number = 4

for attempt in range(1, 11):
    guess = int(input("Attempt " + str(attempt) + ": Guess a number between 1 and 10: "))
    if guess == secret_number:
        print("You guessed right after", attempt, "attempt(s)! You win!")
        break
    else:
        print("Sorry, try again!")
else:
    print("Out of attempts! The correct number was", secret_number)